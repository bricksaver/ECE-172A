clc; clear all; close all;

% There are three functions you need to use from the Potential class.
% The constructor is Potential(x_size, y_size);
% addGoal(loc);
% addRepulsor(loc, intensity, width)
% addAttractor(loc, intensity, width)
% The the comments in Potential for more information on these calls.

initial_loc = [95; 95];
cur_loc = initial_loc';

%COMMENT OUT IF USING FLOORPLAN
goal = [5; 5];

%CODE FOR FLOOR PLAN COMMENTED OUT BELOW
%{
goal = [10; 0];
%}

potentialField = Potential(100, 100);

%COMMENT OUT IF USING FLOORPLAN
repulsor = [50;50]; 

%CODE FOR FLOOR PLAN COMMENTED OUT BELOW
%{
repulsor1 = [10; 90];
repulsor2 = [5; 75];
repulsor3 = [27; 90];
repulsor4 = [50; 75];
repulsor5 = [73; 90];
repulsor6 = [40; 10];
repulsor7 = [78; 10];
repulsor8 = [59; 10];
%}

%COMMENT OUT IF USING FLOORPLAN
attractor = [50; 55]; 

% TODO: Add the goal and repulsors to the potential field.
% They must be added before the next comment.
potentialField.addGoal(goal);

%COMMENT OUT IF USING FLOORPLAN
potentialField.addRepulsor(repulsor,50,50);

%CODE FOR FLOOR PLAN COMMENTED OUT BELOW
%{
potentialField.addRepulsor(repulsor,50,50);
potentialField.addRepulsor(repulsor1,50,50);
potentialField.addRepulsor(repulsor2,25,10);
potentialField.addRepulsor(repulsor3,40,8);
potentialField.addRepulsor(repulsor4,110,100);
potentialField.addRepulsor(repulsor5,40,8);
potentialField.addRepulsor(repulsor6,70,40);
potentialField.addRepulsor(repulsor7,70,40);
potentialField.addRepulsor(repulsor8,70,40);
%}

%COMMENT OUT IF USING FLOORPLAN
potentialField.addAttractor(attractor,1,100); 

%Gradient Stuff


% ************Above Here**************
x = potentialField.x;
y = potentialField.y;
z = potentialField.getField();
dx = potentialField.getdx();
dy = potentialField.getdy();

% TODO: Plot the field in 3 separate figures as follows
% 1) The mesh
% 2) The contours
% 3) The arrows
% On each, indicate where the bot begins with a red asteriks

% mesh plot
figure();
mesh(x,y,z(x,y))
hold on;
% plot red asterix as current location
plot3(cur_loc(1,1),cur_loc(1,2),z(100,100),'r*:');

% contour plot
figure();
contour(x,y,z(x,y))
hold on;
% plot red asterix as current location
plot3(cur_loc(1,1),cur_loc(1,2),z(100,100),'r*:');
% displaying negative gradients on contour plot
quiver(x,y,-dx(x,y),-dy(x,y))

% TODO: Implement the gradient descent algorithm. The dx and dy objects will be
% useful :)

%press key to begin pathing robot
pause;
for i = 1:500
    alpha = 100;
    cur_loc = cur_loc - alpha*[dx(cur_loc(1),cur_loc(2)),dy(cur_loc(1),cur_loc(2))];  
    plot3(cur_loc(1,1), cur_loc(1,2), z(cur_loc(1,1), cur_loc(1,2)), '*r');
    pause(.1);
end
hold off;







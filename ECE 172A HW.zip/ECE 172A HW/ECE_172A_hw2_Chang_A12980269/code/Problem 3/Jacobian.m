%calculates Jacobian

function [dx0,dx1,dx2,dy0,dy1,dy2]=Jacobian(l0,l1,l2,theta0,theta1,theta2)
    dx0 = -l0*sin(theta0)-l1*sin(theta0+theta1)-l2*sin(theta0+theta1+theta2);
    dx1 = -l1*sin(theta0+theta1)-l2*sin(theta0+theta1+theta2);
    dx2 = -l2*sin(theta0+theta1+theta2);
    dy0 = l0*cos(theta0)+l1*cos(theta0+theta1)+l2*cos(theta0+theta1+theta2);
    dy1 = l1*cos(theta0+theta1)+l2*cos(theta0+theta1+theta2);
    dy2 = l2*cos(theta0+theta1+theta2);
end
clc; clear; close all;

data = load('data.mat');
cur_loc = 1;
h = figure();
show_maze(data, h);
draw_cursor(cur_loc, [data.num_rows, data.num_cols], 'r', h);

% TODO: Implement DFS
stack = java.util.Stack;
N = 1400;
goal = N;
visited = zeros(N,1);
parents = zeros(N,1);
stack.push(cur_loc);
while ~isempty(stack) && cur_loc ~= goal
    i = stack.pop();
    cur_loc = i;
    if visited(i) == 0
        visited(i) = 1;
        neighbors = sense_maze(i, data);
        for j = 1:length(neighbors)
            if visited(neighbors(j)) == 0          
                stack.push(neighbors(j));
                parents(neighbors(j)) = cur_loc;
            end
        end
    end
end
cur_loc = goal;
while parents(cur_loc) ~= 0
    draw_cursor(cur_loc, [data.num_rows,data.num_cols], 'g', h);
    cur_loc = parents(cur_loc);
    pause(.001);
end
%}







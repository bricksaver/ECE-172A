%Problem 3

%(ii) - extract data
[trainData,trainLabels,valData,valLabels,testData,testLabels] = extractCifar10('C:\Users\Benjamin Chang\Documents\ECE_172A_hw4_Chang_A12980269\data\Problem_3\cifar-10-batches-mat');

%(iii) - build layers object
layers = [ ...
    imageInputLayer([32 32 3])
    convolution2dLayer(3,16,'Padding','same')
    
    batchNormalizationLayer
    reluLayer
    maxPooling2dLayer(2,'Stride',2)
    convolution2dLayer(3,32,'Padding','same')
    
    batchNormalizationLayer
    reluLayer
    maxPooling2dLayer(2,'Stride',2)
    convolution2dLayer(3,16,'Padding','same')
    
    batchNormalizationLayer
    reluLayer
    fullyConnectedLayer(10)
    softmaxLayer
    classificationLayer];

%(iv) - build options object
valFreq = round(45000/128); %round(num. training samples / mini batch size)
options = trainingOptions('sgdm',...
    'InitialLearnRate',1e-3, ...
    'MaxEpochs',20,...
    'MiniBatchSize',128,...
    'ValidationData',{valData,valLabels},...
    'ValidationFrequency',valFreq,...
    'Plots','training-progress')

%(v) - train network
trainedNet = trainNetwork(trainData, trainLabels, layers, options);

%(vi)
%classify test data
YPred = classify(trainedNet,testData); %holds predictions for test images
%find 3 correctly and 3 incorrectly classified images
correctImages = zeros(32,32,3,3);
incorrectImages = zeros(32,32,3,3);
correctFound = 1;
incorrectFound = 1;
for i = 1:10000
    if correctFound < 4
        if YPred(i) == testLabels(i)
            correctImages(:,:,:,correctFound) = testData(:,:,:,i);
            correctFound = correctFound + 1;
        end
    end
    if incorrectFound < 4
        if YPred(i) ~= testLabels(i)
            incorrectImages(:,:,:,incorrectFound) = testData(:,:,:,i);
            incorrectFound = incorrectFound + 1;
        end
    end
    if correctFound == 3 && incorrectFound == 3
        break;
    end
end
%find weights of 3 correctly and 3 incorrectly classified images
correctPredictWeights = zeros(10,3);
incorrectPredictWeights = zeros(10,3);
for i = 1:3
    correctPredictWeights(:,i) = predict(trainedNet,correctImages(:,:,:,i));
end
for i = 1:3
    incorrectPredictWeights(:,i) = predict(trainedNet,incorrectImages(:,:,:,i));
end
%plot images and weights of 3 correctly and 3 incorrectly classified images
figure;
for i = 1:3
    %plot correct images
    subplot(6,2,2*i-1);
    imshow(uint8(correctImages(:,:,:,i)))
    %plot bar plot of weights
    subplot(6,2,2*i);
    bar(correctPredictWeights(:,i))
    labels = {'airplane', 'car', 'bird','cat','deer','dog','frog','horse','ship','truck'};
    set(gca, 'XTickLabel',labels, 'XTick',1:numel(labels))
end
for i = 1:3
    %plot incorrect images
    subplot(6,2,2*i+5);
    imshow(uint8(incorrectImages(:,:,:,i)))
    %plot bar plot of weights
    subplot(6,2,2*i+6);
    bar(incorrectPredictWeights(:,i))
    labels = {'airplane', 'car', 'bird','cat','deer','dog','frog','horse','ship','truck'};
    set(gca, 'XTickLabel',labels, 'XTick',1:numel(labels))
end
%plot confusion matrix
testLabelsTransposed = zeros(10,10000);
YPredTransposed = zeros(10,10000);
lenTestLabels = length(testLabels);
lenYPred = length(YPred);
for i=1:lenTestLabels
    testLabelsTransposed(testLabels(i),i) = 1;
end
for i=1:lenYPred
    YPredTransposed(YPred(i),i) = 1;
end
plotconfusion(testLabelsTransposed,YPredTransposed);

%(vii)
%slide window over image and get window image
cars2 = imread('cars2.png');
windowSize = [150,200,3]; %window size
[a,b,c] = size(cars2);
paddedCars2 = padarray(cars2,[windowSize(1) windowSize(2)],'both');
[d,e,f] = size(paddedCars2);
stepSize = 10;
windowImage = zeros(windowSize(1),windowSize(2),3);
numWindowedImages = floor(a/stepSize)*floor(b/stepSize);
resizedWindowImages = zeros(32,32,3,numWindowedImages);
halfWinHeightSize = floor(windowSize(1)/2);
halfWinWidthSize = floor(windowSize(2)/2);
heatMap = zeros(floor(a/stepSize),floor(b/stepSize));
g = 1;
for i = windowSize(1):stepSize:d-windowSize(1)
    for j = windowSize(2):stepSize:e-windowSize(2)
        windowImage = paddedCars2(i-halfWinHeightSize:i+halfWinHeightSize,j-halfWinWidthSize:j+halfWinWidthSize,:);
        %resize window image to 32x32 image
        resizedWindowImages(:,:,:,g) = imresize(windowImage, [32 32]);
        g = g + 1;
    end
end
%pass 32x32 window image through nn model to get prediction
classifiedResizedWindowImages = classify(trainedNet,resizedWindowImages);
%get activations
activationsStore = activations(trainedNet,resizedWindowImages,14);
%set heatmap to second unit in softmax layer using activation
k = 1;
for i = 1:65
    for j = 1:128
        heatMap(i,j) = activationsStore(k,2);
        k = k + 1;
    end
end

%plot Neural Network Activation Heatmap of Cars2 Image
figure;
imshow(heatMap)














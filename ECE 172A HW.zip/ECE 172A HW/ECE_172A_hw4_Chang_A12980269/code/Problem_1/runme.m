%% Problem 1.%{ Directional Image Filtering

%1. original image
figure;
imshow(image)

%2. magnitude response of original image
figure;
imagesc((20*log10(abs(fftshift(fft2(image))))))
colormap 'gray';

%3. 4 2x2 subplots of real part of each Gabor filter, image part of
%   each Gabor filter, mag. response of each Gabor filter, magnitude 
%   of image filtered by the 4 Gabor Filters

% 2x2 Subplot of Real Part of Each Gabor Filter
figure;
subplot(2,2,1)
imshow(real(filters(:,:,1)))
title('Real Part of Gabor Filter at Orientation 0')
subplot(2,2,2)
imshow(real(filters(:,:,2)))
title('Real Part of Gabor Filter at Orientation 45')
subplot(2,2,3)
imshow(real(filters(:,:,3)))
title('Real Part of Gabor Filter at Orientation 90')
subplot(2,2,4)
imshow(real(filters(:,:,4)))
title('Real Part of Gabor Filter at Orientation 135')

% 2x2 Subplot of Imag Part of Each Gabor Filter
figure;
subplot(2,2,1)
imshow(imag(filters(:,:,1)))
title('Imag Part of Gabor Filter at Orientation 0')
subplot(2,2,2)
imshow(imag(filters(:,:,2)))
title('Imag Part of Gabor Filter at Orientation 45')
subplot(2,2,3)
imshow(imag(filters(:,:,3)))
title('Imag Part of Gabor Filter at Orientation 90')
subplot(2,2,4)
imshow(imag(filters(:,:,4)))
title('Imag Part of Gabor Filter at Orientation 135')

% 2x2 Subplot of Magnitude Response of Each Gabor Filter
figure;
subplot(2,2,1)
imagesc((20*log10(abs(fftshift(fft2(filters(:,:,1)))))))
title('Mag. Response of Each Gabor Filter 0')
colormap 'gray';
subplot(2,2,2)
imagesc((20*log10(abs(fftshift(fft2(filters(:,:,2)))))))
title('Mag. Response of Each Gabor Filter 45')
colormap 'gray';
subplot(2,2,3)
imagesc((20*log10(abs(fftshift(fft2(filters(:,:,3)))))))
title('Mag. Response of Each Gabor Filter 90')
colormap 'gray';
subplot(2,2,4)
imagesc((20*log10(abs(fftshift(fft2(filters(:,:,4)))))))
title('Mag. Response of Each Gabor Filter 135')
colormap 'gray';

% 2x2 Subplot of Magnitude of Imagees Filtered By Gabor Filters
figure;
subplot(2,2,1)
imshow(abs(conv2(image, filters(:,:,1),'same')))
title('Mag of Image Filtered By Gabor Filter 0')
subplot(2,2,2)
imshow(abs(conv2(image, filters(:,:,2),'same')))
title('Mag of Image Filtered By Gabor Filter 45')
subplot(2,2,3)
imshow(abs(conv2(image, filters(:,:,3),'same')))
title('Mag of Image Filtered By Gabor Filter 90')
subplot(2,2,4)
imshow(abs(conv2(image, filters(:,:,4),'same')))
title('Mag of Image Filtered By Gabor Filter 135')

%4. output image = sum of magnitudes of the four filtered image
figure;
imageMag1 = abs(conv2(image, filters(:,:,1)))
imageMag2 = abs(conv2(image, filters(:,:,2)))
imageMag3 = abs(conv2(image, filters(:,:,3)))
imageMag4 = abs(conv2(image, filters(:,:,4)))
totalImageMag = imageMag1 + imageMag2 + imageMag3 + imageMag4;
imshow(totalImageMag)
title('Sum of Magnitudes of the Four Filtered Images')


%5. magnitude response of output image
figure;
imagesc((20*log10(abs(fftshift(fft2(totalImageMag))))))
colormap 'gray';
title('Magnitude Response of the Sum of the Magnitudes of the Four Filtered Images')





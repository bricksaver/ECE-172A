%% Problem 2
%(i)
% Read Images, Grayscale Images, and Convert Images to Type Double
cars1 = im2double(rgb2gray(imread('cars1.png')));
cars2 = im2double(rgb2gray(imread('cars2.png')));
carsTemplate = im2double(rgb2gray(imread('carsTemplate.png')));
% Find cross-correlation image w/ template using convolution
figure;
imshow(conv2(cars1,carsTemplate),[])
colorbar
%(ii)
% Find normalized cross-correlation image w/ template using convolution
figure;
imshow(normxcorr2(carsTemplate,cars1),[])
colorbar
% Display rectangualar box of same size as template at location with
% highest normalized cross-correlation score
[height, width] = size(carsTemplate);
normxcorrImage = normxcorr2(carsTemplate,cars1);
maxVal = max(max(normxcorrImage));
[maxRow, maxCol] = find(normxcorrImage == maxVal);
[a,b] = size(normxcorrImage);
[c,d] = size(cars1);
topLeftRow = ceil(c/a*(maxCol - width/2));
topLeftCol = ceil(d/b*(maxRow - height/2));
figure;
cars1Rect = cars1;
imshow(cars1Rect)
hold on;
rectangle = size(cars1)
rectangle = insertShape(cars1,'Rectangle',[topLeftRow topLeftCol width height],'LineWidth',5);
imshow(rectangle)
colorbar
%(iii)
%normalized cross-correlation w/ template using convolution
figure;
imshow(normxcorr2(carsTemplate,cars2),[])
colorbar
%figure;
function explore_map = update_explore_map(dest, route, explore_map, PLANNED, UNMAPPED)
% Write this function so that all the locations specified in route and dest
% are marked as PLANNED only if it was previous UNMAPPED in the explore_map
% variable.

destRow = dest(1,1);
destCol = dest(1,2);
if explore_map(destRow,destCol) == UNMAPPED
    explore_map(destRow,destCol) = PLANNED;
end
for i = 1:size(route,1)
    if explore_map(destRow,destCol) == UNMAPPED
        routeRow = route(i,1);
        routeCol = route(i,2);
        explore_map(routeRow,routeCol) = PLANNED;
    end
end

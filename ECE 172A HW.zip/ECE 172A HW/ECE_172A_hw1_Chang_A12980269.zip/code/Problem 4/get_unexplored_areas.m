function unexplored_areas = get_unexplored_areas(explore_map, UNMAPPED)
% Write this function so that unexplored_areas is a Nx2 matrix
% where N is the number of locations the bots have not explored, and each
% row of unexplored_areas represents a location (row,col) in the map.
% We define unexplored areas as locations which have values UNMAPPED in
% explore_map. Locations with values PLANNED/MAPPED/WALL are not considered
% unexplored areas in this case. If there are no unexplored areas, then
% unexplored_areas should return empty [], i.e. unexplored_areas = [];

unexplored_areas = [];
numUnexplored = 0;
for i = 1:50
    for j = 1:50
        if explore_map(i,j)==UNMAPPED
            unexplored_areas(numUnexplored+1,1) = i;
            unexplored_areas(numUnexplored+1,2) = j;
            numUnexplored = numUnexplored + 1;
        end
    end
end


function dest = get_new_destination(curPos, unexplored_areas)
% Write this function so that it will pick the closest unexplored area
% as the new destination dest. We will keep this function simple by
% ignoring any walls that may block our path to the new destination. Here
% we define "closest" using the euclidean distance measure,
% e.g. sqrt((x1-x2)^2 + (y1-y2)^2).

rows = size(unexplored_areas,1);
dest(1,1) = unexplored_areas(1,1);
dest(1,2) = unexplored_areas(1,2);
smallestDist = Inf;
dist = 0;
for i = 1:rows
    dist = sqrt((curPos(1,1)-unexplored_areas(i,1))^2+(curPos(1,2)-unexplored_areas(i,2))^2);
    if dist<smallestDist
        smallestDist = dist;
        dest(1,1) = unexplored_areas(i,1);
        dest(1,2) = unexplored_areas(i,2);
    end
end


%1.

%i)
A = [1 94 2 5; 41 11 0 44; 18 2 113 -9; 8 -5 2 10; 8 8 11 -19];
B = [0 1 0 1; 1 0 1 0; 0 0 1 1; 1 1 0 0; 0 0 1 1];

%ii)
[negARows,negACols] = find(A<0);

%iii)
C = A.*B;

%iv)
innerProductC = C(1,:)*(C(3,:))';

%v)
[minARow,minACol] = find(C == min(C(:)))
[maxARow,maxACol] = find(C == max(C(:)))

%vi)
D = C;
D(:,1) = D(:,1) + C(1,1);
D(:,2) = D(:,2) + C(1,2);
D(:,3) = D(:,3) + C(1,3);
D(:,4) = D(:,4) + C(1,4);
D;

%vii)
innerProductD = D(1,:)*(D(3,:))';


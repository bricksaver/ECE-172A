% Function takes image then enhances it using adaptive histogram equalization (AHE).
% input: image path, contextual region size
% output: image enhanced by AHE 

function [AHEEnhancedImage] = RUNME(im, win_size) %i.e. 'peppers.png'
imageRead = imread(im); %read image
[o,p] = size(imageRead);
 
paddedImageRead = padarray(imageRead,[o p],'symmetric');
[m,n] = size(paddedImageRead);
 
contextual_region = zeros(win_size,win_size);
halfWinSize = floor(win_size/2);
for i = o:m-o
    for j = p:n-p
        rank = 0;
        a = 1;
        b = 1;
        for k = i-halfWinSize:i+halfWinSize
            a = a + 1;
            for l = j-halfWinSize:j+halfWinSize
                b = b + 1;
                contextual_region(a,b) = paddedImageRead(k,l);
                if paddedImageRead(i,j) > paddedImageRead(k,l)
                    rank = rank + 1;
                end
            end
        end
        AHEEnhancedImage(i-o+1,j-p+1) = rank * 255/(win_size*win_size);
    end %The greater the rank of the area surrounding a pixel, the more
        %the pixel will be increased in value(brightness)
imshow(AHEEnhancedImage)
end


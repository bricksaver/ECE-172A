%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%3.(ii)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Produce a simple 11 � 11 test image made up of zeros with 5 ones in it, arranged like the 5
%points in GW Third Edition Figure 10.33(a). Compute and display its HT; the result should
%look like GW Third Edition Figure 10.33(b). Threshold the HT by looking for any (?, ?) cells
%that contains more than 2 votes then plot the corresponding lines in (x,y)-space on top of the
%original image.

clear;
close all;
%create test image
testImage = zeros(11,11);
testImage(1,1) = 1;
testImage(1,end) = 1;
testImage(end,1) = 1;
testImage(end,end) = 1;
testImage(end/2+0.5,end/2+0.5) = 1;

%PLOT ORIGINAL TEST IMAGE
subplot(2,2,1);
imagesc(testImage);
colormap gray; %grayscales image
title('testImage');

%FIND HOUGH TRANSFORM OF IMAGE
[accumulator, rho, theta] = HoughTransform(testImage);
%PLOT HOUGH TRANSFORM
subplot(2,2,[3 4]);
imagesc(accumulator);
colorbar;
colormap gray;
title('Hough Transform');
%set up x-axis
xInterval = 10;
xlabel('theta (deg.)');
set(gca,'Xtick',1:xInterval:length(theta));
set(gca,'Ytick',min(theta):xInterval:max(theta));
%set up y-axis
yInterval = 3;
ylabel('rho');
set(gca,'Ytick',1:yInterval:length(rho));
set(gca,'YtickLabel',min(rho):yInterval:max(rho));

%PLOT ORIGINAL IMAGE WITH OVERLAYED LINES
subplot(2,2,2);
imagesc(testImage);
colormap gray;
title('Overlayed Lines (Threshold > 2)');
hold on;
%overlay threshold image for cells with >2 votes
[rhoPointIndex, thetaPointIndex] = find(accumulator>2);
rhoPoint = rho(rhoPointIndex);
thetaPoint = theta(thetaPointIndex);
slope = -tand(thetaPoint); %tand, not cotd, because for images, we use x-axis for rows & y-axis for columns
xInitial = round(rhoPoint.*cosd(thetaPoint));
yInitial = round(rhoPoint.*sind(thetaPoint));
xMin = 1;
xMax = size(testImage, 1);
yMin = 1;
yMax = size(testImage, 2);
plotEdges(xInitial, yInitial, slope, xMin, xMax, yMin, yMax);

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%3. (iii)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; clear all;
image = imread('lane.png');
image = rgb2gray(image); %grayscale image

%PLOT ORIGINAL IMAGE
figure;
subplot(2,2,1);
imagesc(image,[0 255]); %0 to 255 is number of bins
colormap gray; %turns image into grayscale
title('lanes.png');
%use sobel to find edges w/ its default threshold settings
E = edge(image,'sobel'); %image will have binary pixels
%display image edges
subplot(2,2,2);
imagesc(E);
title('Binary Image Edges');

%FIND HOUGH TRANSFORM OF IMAGE
[accumulator, rho, theta] = HoughTransform(E)
%PLOT HOUGH TRANSFORM
subplot(2,2,3);
imagesc(accumulator);
colormap gray;
colorbar;
title('Hough Transform');
%Set up x-axis label
xInterval = 40;
xlabel('theta (degrees)');
set(gca, 'Xtick', 1:xInterval:length(theta));
set(gca, 'XtickLabel',min(theta):xInterval:max(theta));
%Set up y-axis label
yInterval = 300;
ylabel = ('rho');
set(gca,'Ytick',1:yInterval:length(rho));
set(gca,'YtickLabel',min(rho):yInterval:max(rho));

%IMAGE THRESHOLDED WITH THRESHOLD OF 75%
subplot(2,2,4);
imagesc(image);
colormap gray;
hold on;
title('Thresholded image w/ 75% threshold');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%3. (iii) & (iv)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NOTE THE "%UNCOMMENT 3 LINES BELOW TO SEE ALL LINES DETECTED" BELOW
%Set up line parameters
[rhoPointIndex, thetaPointIndex] = find(accumulator>0.75*max(accumulator(:)));
%show only lines corresponding to driver's lane
%COMMENT OUT 3 LINES BELOW TO SEE ALL LINES DETECTED
index = find(thetaPointIndex>=45 & thetaPointIndex <= 65 | thetaPointIndex >= 120 & thetaPointIndex <= 130);
rhoPointIndex = rhoPointIndex(index); %holds thesholded rho index
thetaPointIndex = thetaPointIndex(index); %holds thresholded theta index
%PLOT EDGES
rhoPoint = rho(rhoPointIndex);
thetaPoint = theta(thetaPointIndex);
slope = -tand(thetaPoint); %tand, not cotd, because for images, we use x-axis for rows & y-axis for columns
xInitial = round(rhoPoint.*cosd(thetaPoint));
yInitial = round(rhoPoint.*sind(thetaPoint));
xMin = 1;
xMax = size(image,1);
yMin = 1;
yMax = size(image,2);
plotEdges(xInitial, yInitial, slope, xMin, xMax, yMin, yMax);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%3. (i)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%HOUGH TRANSFORM FUNCTION
function[accumulator,rho,theta] = HoughTransform(image)
theta = -90:90;
[x,y] = find(image==1);
rhoPts = [x,y]*[cosd(theta); sind(theta)];
rhoPts = round(rhoPts);
rho = min(rhoPts(:)):max(rhoPts(:));
accumulator = hist(rhoPts,rho);
end

%PLOT EDGES FUNCTION
function plotEdges(xInitial,yInitial,slope,xMin,xMax,yMin,yMax)
%Plots lines using the given inital x,y point and slope between them
%points at the border of the image and plots a line between them

for i = 1:length(xInitial)
    slopei = slope(i);
    xI = xInitial(i);
    yI = yInitial(i);
    xOne = xMin;
    yOne = (xMin-xI)/slopei+yI;
    xTwo = xMax;
    yTwo = (xMax-xI)/slopei+yI;
    yThree = yMin;
    xThree = (yMin-yI)*slopei+xI;
    yFour = yMax;
    xFour = (yMax-yI)*slopei+xI;
    counter = 1;
    x = zeros(1,2);
    y = zeros(1,2);
    if ((yOne>=yMin) && (yOne<=yMax))
        x(counter) = xOne;
        y(counter) = yOne;
        counter = counter + 1;
    end
    if ((yTwo>=yMin) && (xTwo<=xMax))
        x(counter) = xTwo;
        y(counter) = yTwo;
        counter = counter + 1;
    end
    if ((yThree>=yMin) && (xThree<=xMax))
        x(counter) = xThree;
        y(counter) = yThree;
        counter = counter + 1;
    end
    if ((xFour>=xMin) && (xFour<=xMax))
        x(counter) = xFour;
        y(counter) = yFour;
    end
    plot([y(1) y(2)],[x(1) x(2)],'r','LineWidth',1.5);
end
end
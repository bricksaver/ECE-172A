% Function takes image then samples and quantizes it.
% input: image path
% output: sampled and quantized image
 
function [sampledAndQuantizedImage] = RUNME(imagePath) %i.e. 'peppers.png'
imageRead = imread(imagePath); %read image
[m,n] = size(imageRead);
sampledImage = imageRead(1:10:m, 1:10:n); %samples image every 10 rows and cols
sampledAndQuantizedImage = floor(sampledImage./51)*51; %5-level quantization of sampled images so bins
                                  %cover all grayscale values (0 to 255)
imshow(sampledAndQuantizedImage)
end
